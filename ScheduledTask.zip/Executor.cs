namespace $rootnamespace$
{
    public partial class $safeitemname$ : Form
    {
        private Scheduled scheduled;
        private Thread? reminderThread;

        public $safeitemname$()
        {
            InitializeComponent();
            scheduled = new Scheduled();
            scheduled.UpdateTaskCallback = UpdateTaskInListBox;
            dateTimePicker.Format = DateTimePickerFormat.Custom;
            dateTimePicker.CustomFormat = "dd.MM.yyyy HH:mm";
            StartReminderThread();
        }

        private void StartReminderThread()
        {
            reminderThread = new Thread(ReminderLoop);
            reminderThread.IsBackground = true;
            reminderThread.Start();
        }

        private void ReminderLoop()
        {
            while (true)
            {
                DateTime now = DateTime.Now;
                List<Task> dueTasks = scheduled.GetDueTasks(now);
                foreach (Task task in dueTasks)
                {
                    MessageBox.Show(task.Description, "�����������");
                }
                Thread.Sleep(1000);
            }
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            DateTime executionTime = dateTimePicker.Value;
            if (executionTime < DateTime.Now)
            {
                MessageBox.Show("�� �� ������ ���������� ������ �� ������ ����.", "�������");
                return;
            }

            string description = txtDescription.Text;
            Task task = new Task(description, executionTime);
            scheduled.AddTask(task);
            listBoxTasks.Items.Add(task);
            MessageBox.Show("�������� ����������� ������!", "ϳ�����������");

            dateTimePicker.Value = DateTime.Now;
            txtDescription.Text = "";

            scheduled.UpdateReminder();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (listBoxTasks.SelectedItem != null)
            {
                Task selectedTask = (Task)listBoxTasks.SelectedItem;
                scheduled.RemoveTask(selectedTask);
                listBoxTasks.Items.Remove(selectedTask);
            }
            else
            {
                MessageBox.Show("�������� ������� ������ ��� ���������.", "�������");
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (listBoxTasks.SelectedItem != null)
            {
                Task selectedTask = (Task)listBoxTasks.SelectedItem;
                int selectedIndex = listBoxTasks.SelectedIndex;
                using (Form editForm = scheduled.CreateEditForm(selectedTask))
                {
                    if (editForm.ShowDialog() == DialogResult.OK)
                    {
                        scheduled.RemoveTask(selectedTask);
                        listBoxTasks.Items.RemoveAt(selectedIndex);

                        Task updatedTask = selectedTask;
                        scheduled.AddTask(updatedTask);
                        listBoxTasks.Items.Insert(selectedIndex, updatedTask);

                        scheduled.UpdateReminder();
                    }
                }
            }
            else
            {
                MessageBox.Show("�������� ������� ������ ��� �����������.", "�������");
            }
        }

        private void UpdateTaskInListBox(Task task)
        {
            int index = listBoxTasks.Items.IndexOf(task);
            if (index != -1)
            {
                listBoxTasks.Items[index] = task;
            }
        }
    }
}